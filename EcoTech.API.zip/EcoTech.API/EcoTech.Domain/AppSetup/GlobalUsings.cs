﻿global using FluentValidation;
global using Mediator;
global using System.Linq.Expressions;
global using EcoTech.Domain.AppSetup;
global using FluentValidation.Results;
global using FastEndpoints;
global using EcoTech.Domain.Entities;
global using EcoTech.Shared.Constants;
