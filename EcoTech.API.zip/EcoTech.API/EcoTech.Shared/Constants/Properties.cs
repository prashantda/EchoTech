﻿
namespace EcoTech.Shared.Constants;

public static class Properties
{
 // public static MyProperties abc { get; } = new MyProperties();
}
/*public class MyProperties
{
    public int JwtToken { get; } = 1;
}*/
